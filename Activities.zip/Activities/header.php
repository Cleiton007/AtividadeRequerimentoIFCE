<?php
    header('location:atividade.php');
?>